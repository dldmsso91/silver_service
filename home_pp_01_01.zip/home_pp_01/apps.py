from django.apps import AppConfig


class HomePp01Config(AppConfig):
    name = 'home_pp_01'
